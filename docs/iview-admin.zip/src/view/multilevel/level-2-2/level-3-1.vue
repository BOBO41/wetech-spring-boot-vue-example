<template>
  <div>多级菜单 -> 二级-2 -> 3级</div>
</template>
<script>
export default {
  name: 'level_3_1'
}
</script>
